<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Information</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 20px;
            background-color: #f4f4f4;
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: white;
            box-shadow: 0px 0px 10px gray;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        img {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn {
            margin-top: 20px;
            padding: 10px 20px;
            background: blue;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .delete-btn, .edit-btn {
            background: red;
            color: white;
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .edit-btn {
            background: green;
        }
        .delete-btn:hover {
            background: darkred;
        }
        .edit-btn:hover {
            background: darkgreen;
        }
    </style>
</head>
<body>

<h2>Saved Information</h2>

<table>
    <tr>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Gender</th>
        <th>Location</th>
        <th>Country</th>
        <th>Occupation</th>
        <th>Photo</th>
        <th>Document</th>
        <th>Action</th> <!-- Edit & Delete Column -->
    </tr>

    <?php
    $conn = new mysqli("localhost", "root", "", "user_database");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $result = $conn->query("SELECT * FROM users");

    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row["first_name"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["last_name"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["gender"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["location"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["country"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["occupation"]) . "</td>";
        echo "<td>
                <a href='" . htmlspecialchars($row["photo"]) . "' target='_blank'>
                    <img src='" . htmlspecialchars($row["photo"]) . "'>
                </a>
                <br>
                <button class='edit-btn' onclick='editPhoto(" . $row["id"] . ")'>Edit</button>
              </td>";
        echo "<td><a href='" . htmlspecialchars($row["document"]) . "' target='_blank'>View</a></td>";
        echo "<td><button class='delete-btn' onclick='confirmDelete(" . $row["id"] . ")'>Delete</button></td>";
        echo "</tr>";
    }

    $conn->close();
    ?>
</table>

<button class="btn" onclick="window.location.href='index.php'">Back</button>

<script>
    function confirmDelete(id) {
        if (confirm("Are you sure you want to delete this record?")) {
            window.location.href = "delete.php?id=" + id;
        }
    }

    function editPhoto(id) {
        window.location.href = "edit_photo.php?id=" + id;
    }
</script>

</body>
</html>
