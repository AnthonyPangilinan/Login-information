<?php
// Fetch the latest uploaded photo
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user_database";

$conn = new mysqli($servername, $username, $password, $dbname);
$profilePhoto = "default-avatar.png"; // Default image

$result = $conn->query("SELECT photo FROM users ORDER BY id DESC LIMIT 1");
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (!empty($row["photo"])) {
        $profilePhoto = $row["photo"];
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personal Information Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px gray;
            width: 400px;
            position: relative;
            text-align: center;
        }
        .profile-picture {
            position: absolute;
            top: 10px;
            right: 10px;
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 2px solid gray;
            object-fit: cover;
        }
        .form-group {
            margin-bottom: 10px;
            text-align: left;
        }
        label {
            font-weight: bold;
            display: block;
        }
        input, select {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .gender-group {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        .gender-group label {
            display: flex;
            align-items: center;
            gap: 5px;
            font-weight: normal;
        }
        button {
            background-color: blue;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            width: 100%;
            cursor: pointer;
            margin-top: 10px;
        }
        button.view-btn {
            background: green;
        }
        button.logout-btn {
            background: red;
        }
    </style>
</head>
<body>

<div class="container">
    <img src="<?= $profilePhoto ?>" alt="Profile Picture" class="profile-picture">

    <h2>Personal Information</h2>
    <form action="process.php" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="first_name">First Name:</label>
            <input type="text" id="first_name" name="first_name" required>
        </div>

        <div class="form-group">
            <label for="last_name">Last Name:</label>
            <input type="text" id="last_name" name="last_name" required>
        </div>

        <div class="form-group">
            <label>Gender:</label>
            <div class="gender-group">
                <label for="male">
                    <input type="radio" id="male" name="gender" value="Male" required> Male
                </label>
                <label for="female">
                    <input type="radio" id="female" name="gender" value="Female" required> Female
                </label>
            </div>
        </div>

        <div class="form-group">
            <label for="location">Location:</label>
            <input type="text" id="location" name="location" required>
        </div>

        <div class="form-group">
            <label for="photo">Upload Photo:</label>
            <input type="file" id="photo" name="photo" accept="image/*" required>
        </div>

        <div class="form-group">
            <label for="country">Country:</label>
            <select id="country" name="country" required>
                <option value="">Select Country</option>
                <option value="USA">USA</option>
                <option value="Philippines">Philippines</option>
                <option value="UK">UK</option>
                <option value="Australia">Australia</option>
                <option value="India">India</option>
                <option value="Other">Other</option>
            </select>
        </div>

        <div class="form-group">
            <label for="occupation">Occupation:</label>
            <input type="text" id="occupation" name="occupation" required>
        </div>

        <div class="form-group">
            <label for="document">Upload Document:</label>
            <input type="file" id="document" name="document" accept=".pdf,.doc,.docx" required>
        </div>

        <button type="submit">Submit</button>
        <button type="button" class="view-btn" onclick="window.location.href='view.php'">View Information</button>
        <button type="button" class="logout-btn" onclick="window.location.href='logout.php'">Logout</button>
    </form>
</div>

</body>
</html>
