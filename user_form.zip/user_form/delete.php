<?php
$conn = new mysqli("localhost", "root", "", "user_database");

if (isset($_GET["id"])) {
    $id = $_GET["id"];

    // Delete record from database
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "<script>alert('Record deleted successfully!'); window.location='view.php';</script>";
    } else {
        echo "<script>alert('Error deleting record!'); window.location='view.php';</script>";
    }

    $stmt->close();
    $conn->close();
}
?>
