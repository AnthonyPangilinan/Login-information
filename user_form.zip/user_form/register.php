<?php
session_start();
$conn = new mysqli("localhost", "root", "", "user_database"); // Ensure this is correct

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $age = $_POST["age"];
    $phone_number = $_POST["phone_number"];
    $password = password_hash($_POST["password"], PASSWORD_BCRYPT);

    // Insert user into database
    $stmt = $conn->prepare("INSERT INTO users (username, age, phone_number, password) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("siss", $username, $age, $phone_number, $password);

    if ($stmt->execute()) {
        echo "<script>alert('Registration successful! You can now login.'); window.location='login.php';</script>";
    } else {
        echo "<script>alert('Error: Could not register.');</script>";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Register</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            text-align: center;
        }
        input {
            width: 90%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            width: 100%;
            padding: 10px;
            background-color: blue;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: darkblue;
        }
        a {
            display: block;
            margin-top: 10px;
            text-decoration: none;
            color: blue;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Register</h2>
        <form method="post">
            <input type="text" name="username" placeholder="Username" required><br>
            <input type="number" name="age" placeholder="Age" required><br>
            <input type="text" name="phone_number" placeholder="Phone Number" required><br>
            <input type="password" name="password" placeholder="Password" required><br>
            <button type="submit">Create a new account</button>
        </form>
        <a href="login.php">Already have an account? Login</a>
    </div>
</body>
</html>
