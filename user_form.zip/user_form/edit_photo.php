<?php
$conn = new mysqli("localhost", "root", "", "user_database");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user ID from URL
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
} else {
    die("Invalid request.");
}

// Fetch current photo
$result = $conn->query("SELECT photo FROM users WHERE id = $id");
$row = $result->fetch_assoc();
$currentPhoto = $row['photo'];

// Handle photo update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $targetDir = "uploads/";
    $targetFile = $targetDir . basename($_FILES["photo"]["name"]);
    
    if (move_uploaded_file($_FILES["photo"]["tmp_name"], $targetFile)) {
        // Update database with new photo path
        $stmt = $conn->prepare("UPDATE users SET photo = ? WHERE id = ?");
        $stmt->bind_param("si", $targetFile, $id);
        if ($stmt->execute()) {
            echo "<script>alert('Photo updated successfully!'); window.location='view.php';</script>";
        } else {
            echo "Error updating photo.";
        }
        $stmt->close();
    } else {
        echo "Error uploading file.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Photo</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 50px;
        }
        img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        input {
            margin-top: 10px;
        }
        button {
            padding: 10px 15px;
            background: green;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background: darkgreen;
        }
    </style>
</head>
<body>

<h2>Edit Photo</h2>
<img src="<?= htmlspecialchars($currentPhoto) ?>" alt="Current Photo"><br>

<form method="post" enctype="multipart/form-data">
    <input type="file" name="photo" required><br>
    <button type="submit">Update Photo</button>
</form>

</body>
</html>
