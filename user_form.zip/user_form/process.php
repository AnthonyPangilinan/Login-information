<?php
session_start();
$conn = new mysqli("localhost", "root", "", "user_database");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = $_POST["first_name"];
    $last_name = $_POST["last_name"];
    $gender = $_POST["gender"];
    $location = $_POST["location"];
    $country = $_POST["country"];
    $occupation = $_POST["occupation"];

    // File upload handling for photo
    $photo = "default-avatar.png"; // Default image
    if (!empty($_FILES["photo"]["name"])) {
        $photo = "uploads/" . basename($_FILES["photo"]["name"]);
        move_uploaded_file($_FILES["photo"]["tmp_name"], $photo);
    }

    // File upload handling for document
    $document = NULL;
    if (!empty($_FILES["document"]["name"])) {
        $document = "uploads/" . basename($_FILES["document"]["name"]);
        move_uploaded_file($_FILES["document"]["tmp_name"], $document);
    }

    // Insert into database
    $stmt = $conn->prepare("INSERT INTO users (first_name, last_name, gender, location, country, occupation, photo, document) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssss", $first_name, $last_name, $gender, $location, $country, $occupation, $photo, $document);

    if ($stmt->execute()) {
        echo "<script>
                alert('Successfully saved information.');
                window.location.href='index.php'; 
              </script>";
    } else {
        echo "<script>alert('Error: Could not save data.');</script>";
    }

    $stmt->close();
    $conn->close();
}
?>
